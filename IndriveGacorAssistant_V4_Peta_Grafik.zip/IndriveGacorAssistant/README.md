# INDRIVE GACOR ASSISTANT — Anung Channel

Project Android sederhana untuk mencatat waktu dan lokasi aktivitas secara manual, menyimpan riwayat secara lokal, dan melihat ringkasan jumlah catatan per jam.

- Tidak memodifikasi aplikasi inDrive.
- Tidak membaca sistem internal inDrive atau mengambil order otomatis.
- Tidak menjamin jumlah order/penumpang.
- Gunakan HP hanya saat kendaraan berhenti dan aman.

Target kompatibilitas: Android 6+ (diuji konfigurasi build untuk Android 12). APK perlu dibangun melalui Android Studio/CI.
