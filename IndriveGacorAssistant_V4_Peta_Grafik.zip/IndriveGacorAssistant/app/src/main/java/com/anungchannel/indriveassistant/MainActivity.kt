package com.anungchannel.indriveassistant

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Typeface
import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var history: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private var lastLocation = "Lokasi belum diambil"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("orders", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 22) }
        root.addView(TextView(this).apply { text = "INDRIVE GACOR ASSISTANT\nby Anung Channel"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = "Catat perjalanan dan pelajari pola waktu/lokasi dari data sendiri. Aplikasi ini tidak menjamin order dan tidak mengubah inDrive."; textSize = 14f; setPadding(0,12,0,16) })
        status = TextView(this).apply { text = lastLocation; textSize = 14f }
        root.addView(status)
        root.addView(button("Ambil lokasi GPS") { getLocation() })
        root.addView(button("Catat order / titik aktivitas") { saveRecord() })
        root.addView(button("Analisis jam aktivitas") { showAnalysis() })
        root.addView(button("Hapus riwayat") { prefs.edit().clear().apply(); refresh() })
        root.addView(TextView(this).apply { text = "Riwayat catatan"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setPadding(0,18,0,8) })
        history = TextView(this).apply { textSize = 13f }
        root.addView(ScrollView(this).apply { addView(history) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun getLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10); return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc: Location? = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            lastLocation = if (loc != null) "GPS: ${loc.latitude}, ${loc.longitude}" else "Lokasi belum tersedia. Aktifkan GPS dan coba lagi."
            status.text = lastLocation
        } catch (_: Exception) { status.text = "Tidak bisa mengambil lokasi. Periksa izin GPS." }
    }
    private fun saveRecord() {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val old = prefs.getString("records", "") ?: ""
        val row = "$stamp | $lastLocation"
        prefs.edit().putString("records", if (old.isBlank()) row else "$row\n$old").apply()
        refresh(); Toast.makeText(this, "Catatan disimpan", Toast.LENGTH_SHORT).show()
    }
    private fun refresh() { history.text = prefs.getString("records", "Belum ada catatan") }
    private fun showAnalysis() {
        val rows = (prefs.getString("records", "") ?: "").lines().filter { it.isNotBlank() }
        if (rows.isEmpty()) { Toast.makeText(this, "Belum ada data untuk dianalisis", Toast.LENGTH_SHORT).show(); return }
        val counts = rows.mapNotNull { it.substringAfter(" ").take(2).toIntOrNull() }.groupingBy { it }.eachCount().toList().sortedByDescending { it.second }
        val msg = if (counts.isEmpty()) "Data belum cukup." else counts.take(5).joinToString("\n") { "Jam ${it.first}:00 — ${it.second} catatan" }
        android.app.AlertDialog.Builder(this).setTitle("Ringkasan jam aktivitas").setMessage("Berdasarkan ${rows.size} catatan yang Aa simpan:\n$msg\n\nIni hanya ringkasan riwayat, bukan prediksi atau jaminan order.").setPositiveButton("Tutup", null).show()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) getLocation() }
}
